## Debug Cubemap

Debug cubemap textures from:
https://github.com/BabylonJS/Babylon.js/tree/master/packages/tools/playground/public/textures/cubemapDebug

Licensed under Apache2.
